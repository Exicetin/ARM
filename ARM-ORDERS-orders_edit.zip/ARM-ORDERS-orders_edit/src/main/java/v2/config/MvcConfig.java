package v2.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

//@Configuration
//@EnableWebMvc
//public class MvcConfig extends WebMvcConfig {

//    @Override
//    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//        registry.addResourceHandler("/resources/static/**")
//                .addResourceLocations("classpath:/resources/static/css/")
//                .setCachePeriod(0);

//    }

//}